﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;
using UnityEngine.UI;

public class StateHolder : MonoBehaviour {
    // Some common variables
    public string[] boardPlayers;

    private bool newBoard = true;
    public string currentBoardScene;

    // Stuff to store between scenes
    public int[] boardPlayerScores;
    public string[] boardPlayerPositions;
    private int bonusPoints = 0;
    private string callingPlayer;
    private bool miniGameWon = false;
    public int turnsRemaining = 0;
    public int pointsToWin = 2000;

    // Sound Stuff
    public AudioSource audioSource;
    public AudioClip winSound;
    public AudioClip loseSound;

    // JSON Loading Stuff
    private const string miniGameListPath = "MiniGameList.json";
    // MiniGame List
    [Serializable]
    public class MiniGameData
    {
        public MiniGame[] minigames;
    }

    // MiniGame Class
    [Serializable]
    public class MiniGame
    {
        public string id;
        public string name;
        public string sceneName;
        public string description;
        public string screenshotPath;
        public string controlsPath;
    }

    // Dictionary
    public Dictionary<string, MiniGame> miniGameDictionary;
    // Array]
    public MiniGame[] miniGameArray;

    private void LoadMiniGameList(string fileName)
    {
        miniGameDictionary = new Dictionary<string, MiniGame> ();
        string filePath = Path.Combine(Application.streamingAssetsPath, fileName);
        if (File.Exists(filePath))
        {
            string dataAsJson = File.ReadAllText(filePath);
            MiniGameData loadedData = JsonUtility.FromJson<MiniGameData>(dataAsJson);
            miniGameArray = loadedData.minigames;
            for (int i = 0; i < loadedData.minigames.Length; i++)
            {
                miniGameDictionary.Add(miniGameArray[i].id, miniGameArray[i]);
            }
            Debug.Log("Data loaded, dictionary contains: " + miniGameDictionary.Count + " entries");
        }
        else
        {
            Debug.LogError("MiniGame Data Not Found!");
        }
    }

    //
    private void Awake()
    {
        // Set persitence to things
        DontDestroyOnLoad(this);
        // Prevent duplicates
        if (FindObjectsOfType(GetType()).Length > 1)
        {
            Destroy(this.gameObject);
        }
    }

    // Use this for initialization
    void Start () {
        currentBoardScene = SceneManager.GetActiveScene().name;
        boardPlayerScores = new int[boardPlayers.Length];
        boardPlayerPositions = new string[boardPlayers.Length];

        // Load minigame data
        LoadMiniGameList(miniGameListPath);
	}

    public void setBonusPoints(int v)
    {
        bonusPoints = v;
    }

    public int getBonusPointS()
    {
        return bonusPoints;
    }

    // Update is called once per frame
    void Update () {
		
	}

    public void loadMiniGame(string miniGameName, BoardPlayer callingPlayer, GameObject callingPoint)
    {
        for (int i = 0; i < boardPlayers.Length; i++)
        {
            boardPlayerScores[i] = GameObject.Find(boardPlayers[i]).GetComponent<BoardPlayer>().getPlayerPoints();
            boardPlayerPositions[i] = callingPoint.name;    // TODO: Fix this
            GameObject.Find(boardPlayers[i]).SetActive(false);
        }
        this.callingPlayer = callingPlayer.name;
        SceneManager.LoadScene(miniGameName);
    }

    public void returnToMainMenu()
    {
        SceneManager.LoadScene("ChaoMainMenu");
        Destroy(this.gameObject);
    }

    public void returnToBoard(bool winning)
    {
        SceneManager.LoadScene(currentBoardScene);
        // Add delegate to listen for level load
        SceneManager.sceneLoaded += onBoardLoaded;
        miniGameWon = winning;
    }

    // If we're waiting for a board to load, and it finishes, run this to re-init players etc.
    private void onBoardLoaded(Scene scene, LoadSceneMode mode)
    {
        Debug.Log("Loaded Board Again");
        for (int i = 0; i < boardPlayers.Length; i++)
        {
            // Get Reference to BoardPlayer GameObject and Script
            GameObject currentPlayer = GameObject.Find(boardPlayers[i]);
            BoardPlayer currentPlayerScript = currentPlayer.GetComponent<BoardPlayer>();
            // Restore Points
            currentPlayerScript.setPlayerPoints(boardPlayerScores[i]);
            // Restore Board Position
            GameObject originalPoint = GameObject.Find(boardPlayerPositions[0]);
            currentPlayerScript.currentTarget = originalPoint.GetComponent<PointScript>().nextPoints[0];
            currentPlayer.transform.position = originalPoint.transform.position;
        }
        // Apply bonus points
        if (miniGameWon)
        {
            GameObject.Find(callingPlayer).GetComponent<BoardPlayer>().addPlayerPoints(bonusPoints);
            // Play win sound
            audioSource.clip = winSound;
            audioSource.Play();
        }
        else {
            // Play lose sound
            audioSource.clip = loseSound;
            audioSource.Play();
        }
        // End the game possibly HACK
        if (turnsRemaining <= 0)
        {
            // If win
            // Find the player and get his points and see if they add up to 2000
            int playerPoints = GameObject.Find(boardPlayers[0]).GetComponent<BoardPlayer>().getPlayerPoints();
            if (playerPoints > pointsToWin)
            {
                GameObject dialogBox = GameObject.Find("MainDialogBox");
                if (dialogBox != null)
                {
                    dialogBox.transform.GetChild(0).gameObject.GetComponent<Text>().text = "YOU WON!\nPRESS FIRE TO EXIT";
                    dialogBox.transform.GetChild(1).gameObject.GetComponent<Text>().text = "CONGRATULATIONS!";
                    string screenshotPath = "MiniGamePreviews/BlankPreview";
                    string controlsPath = "ControlPreviews/BlankControls";
                    dialogBox.transform.GetChild(2).gameObject.GetComponent<RawImage>().texture = Resources.Load<Texture2D>(screenshotPath);
                    dialogBox.transform.GetChild(3).gameObject.GetComponent<RawImage>().texture = Resources.Load<Texture2D>(controlsPath);
                    dialogBox.SetActive(true);
                    dialogBox.GetComponent<DialogBoxScript>().selfDisable = false;
                    StartCoroutine(waitingToExit());
                    //waitingForDialogue = true;
                    // Play win sound
                    audioSource.clip = winSound;
                    audioSource.Play();
                }
            }
            else
            {
                GameObject dialogBox = GameObject.Find("MainDialogBox");
                if (dialogBox != null)
                {
                    dialogBox.transform.GetChild(0).gameObject.GetComponent<Text>().text = "You lost...\nPRESS FIRE TO EXIT";
                    dialogBox.transform.GetChild(1).gameObject.GetComponent<Text>().text = "Whoops!";
                    string screenshotPath = "MiniGamePreviews/BlankPreview";
                    string controlsPath = "ControlPreviews/BlankControls";
                    dialogBox.transform.GetChild(2).gameObject.GetComponent<RawImage>().texture = Resources.Load<Texture2D>(screenshotPath);
                    dialogBox.transform.GetChild(3).gameObject.GetComponent<RawImage>().texture = Resources.Load<Texture2D>(controlsPath);
                    dialogBox.SetActive(true);
                    dialogBox.GetComponent<DialogBoxScript>().selfDisable = false;
                    StartCoroutine(waitingToExit());
                    //waitingForDialogue = true;
                    // Play lose sound
                    audioSource.clip = loseSound;
                    audioSource.Play();
                }
            }
        }

        // Turn off this function call now that it's loaded
        SceneManager.sceneLoaded -= onBoardLoaded;
    }

    private IEnumerator waitingToExit()
    {
        bool waiting = true;
        while (waiting)
        {
            if (Input.GetButtonDown("Fire1"))
            {
                waiting = false;
            }
            yield return null;
        }
        returnToMainMenu();
    }
}
