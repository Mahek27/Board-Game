﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DebugMiniGameHWScript : MonoBehaviour {

    public StateHolder stateHolder;

	// Use this for initialization
	void Start () {
        stateHolder = GameObject.Find("StateHolder").GetComponent<StateHolder>();
        GetComponent<Text>().text = string.Format("Cool Info:\nCurrent Board Name: {0}\nPlayer 1 Object Name: {1}\nScore: {2}\nPlayer 1 Point Name: {3}\n", 
            stateHolder.currentBoardScene, stateHolder.boardPlayers[0], stateHolder.boardPlayerScores[0], stateHolder.boardPlayerPositions[0]);
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetButtonDown("Fire1"))
        {
            stateHolder.returnToBoard(true);
        }
	}
}
