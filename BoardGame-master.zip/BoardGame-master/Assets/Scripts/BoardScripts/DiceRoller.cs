﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DiceRoller : MonoBehaviour
{
    // Variable setup
    private Text thisText;
    private bool waitingForRoll = false;
    // Links to other objects
    private BoardPlayer player1script;


    // Use this for initialization
    void Start()
    {
        player1script = GameObject.Find("Mario-Big").GetComponent<BoardPlayer>();
        thisText = GetComponent<Text>();
        // Get the Dice Rolling
        rollDicePrompt();
    }

    // Update is called once per frame
    void Update()
    {
        if (waitingForRoll && Input.GetButtonDown("Fire1"))
        {
            performDiceRoll();
        }
        else if (!waitingForRoll && !player1script.getTurnActive())
        {
            rollDicePrompt();
        }
    }

    private void rollDicePrompt()
    {
        thisText.text = "Press Fire to Roll Dice";
        waitingForRoll = true;
    }

    private void performDiceRoll()
    {
        waitingForRoll = false;
        int rollNumber = Random.Range(1, 7);
        //thisText.text = string.Format("Dice Rolled: {0}", rollNumber);
        thisText.text = "";
        player1script.setMovementAmount(rollNumber);
    }
}
