﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PointScript_JSONLoader : PointScript
{
    //public GameObject[] nextPoints;
    public GameObject dialogBox;
    private StateHolder stateHolder;

    private bool waitingForDialogue = false;
    private BoardPlayer currentPlayerObject;

    // Defined Variables
    public int pointReward;
    public string miniGameId;

    // Use this for initialization
    void Start()
    {
        //dialogBox = GameObject.Find("MainDialogBox");
        stateHolder = GameObject.Find("StateHolder").GetComponent<StateHolder>();
        //dialogBox.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (waitingForDialogue && Input.GetButtonDown("Fire1"))
        {
            dialogBox.SetActive(false);
            waitingForDialogue = false;
            currentPlayerObject.setTurnActive(false);
            stateHolder.setBonusPoints(pointReward);
            stateHolder.loadMiniGame(stateHolder.miniGameDictionary[miniGameId].sceneName, currentPlayerObject, this.gameObject);
        }
    }

    public override void onLanding(BoardPlayer callingPlayerScript)
    {
        currentPlayerObject = callingPlayerScript;
        //int playersPoints = callingPlayerScript.addPlayerPoints(10);
        //Debug.Log(string.Format("Player 1 Score: {0}\n", playersPoints));
        // Load appropriate assets into place
        dialogBox.transform.GetChild(0).gameObject.GetComponent<Text>().text = stateHolder.miniGameDictionary[miniGameId].description;
        dialogBox.transform.GetChild(1).gameObject.GetComponent<Text>().text = stateHolder.miniGameDictionary[miniGameId].name;
        string screenshotPath = "MiniGamePreviews/" + stateHolder.miniGameDictionary[miniGameId].screenshotPath;
        string controlsPath = "ControlPreviews/" + stateHolder.miniGameDictionary[miniGameId].controlsPath;
        dialogBox.transform.GetChild(2).gameObject.GetComponent<RawImage>().texture = Resources.Load<Texture2D>(screenshotPath);
        dialogBox.transform.GetChild(3).gameObject.GetComponent<RawImage>().texture = Resources.Load<Texture2D>(controlsPath);
        dialogBox.SetActive(true);
        waitingForDialogue = true;
        //callingPlayerScript.setTurnActive(false);
    }
}
