﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PointScript_Test2 : PointScript
{
    //public GameObject[] nextPoints;
    public GameObject dialogBox;
    private StateHolder stateHolder;

    private bool waitingForDialogue = false;
    private BoardPlayer currentPlayerObject;

    // Use this for initialization
    void Start()
    {
        //dialogBox = GameObject.Find("MainDialogBox");
        stateHolder = GameObject.Find("StateHolder").GetComponent<StateHolder>();
        dialogBox.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (waitingForDialogue && Input.GetButtonDown("Fire1"))
        {
            dialogBox.SetActive(false);
            waitingForDialogue = false;
            currentPlayerObject.setTurnActive(false);
            stateHolder.loadMiniGame("DebugMiniGame1", currentPlayerObject, this.gameObject);
        }
    }

    public override void onLanding(BoardPlayer callingPlayerScript)
    {
        currentPlayerObject = callingPlayerScript;
        int playersPoints = callingPlayerScript.addPlayerPoints(10);
        //Debug.Log(string.Format("Player 1 Score: {0}\n", playersPoints));
        dialogBox.transform.GetChild(0).gameObject.GetComponent<Text>().text = "Super Special Debug Game!!!\n\n\nPress Fire to Continue\n";
        dialogBox.SetActive(true);
        waitingForDialogue = true;
        //callingPlayerScript.setTurnActive(false);
    }
}
