﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PointScript_Demo_LastPoint : PointScript
{
    //public GameObject[] nextPoints;
    public GameObject dialogBox;
    private StateHolder stateHolder;

    private bool waitingForDialogue = false;
    private BoardPlayer currentPlayerObject;

    // Use this for initialization
    void Start()
    {
        //dialogBox = GameObject.Find("MainDialogBox");
        stateHolder = GameObject.Find("StateHolder").GetComponent<StateHolder>();
        dialogBox.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (waitingForDialogue && Input.GetButtonDown("Fire1"))
        {
            // Probably do something here
            stateHolder.returnToMainMenu();
            /*dialogBox.SetActive(false);
            waitingForDialogue = false;
            currentPlayerObject.setTurnActive(false);
            stateHolder.loadMiniGame("DebugMiniGame1", currentPlayerObject, this.gameObject);*/
        }
    }

    public override void onLanding(BoardPlayer callingPlayerScript)
    {
        currentPlayerObject = callingPlayerScript;
        int playersPoints = callingPlayerScript.addPlayerPoints(10);
        //Debug.Log(string.Format("Player 1 Score: {0}\n", playersPoints));
        if (callingPlayerScript.getPlayerPoints() >= 150) {
            dialogBox.transform.GetChild(0).gameObject.GetComponent<Text>().text = "You Win!!!\n\n\nPress Fire to Continue\n";
        }
        else
        {
            dialogBox.transform.GetChild(0).gameObject.GetComponent<Text>().text = "You lose...\n\n\nPress Fire to Continue\n";
        }
        
        dialogBox.SetActive(true);
        waitingForDialogue = true;
        //callingPlayerScript.setTurnActive(false);
    }
}
