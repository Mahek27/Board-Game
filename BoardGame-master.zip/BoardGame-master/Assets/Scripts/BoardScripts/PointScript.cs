﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class PointScript : MonoBehaviour {

    public GameObject[] nextPoints;

    // Use this for initialization
    //public abstract void Start();

    // Update is called once per frame
    //public abstract void Update();

    // Called by the current player upon landing on a space
    public virtual void onLanding(BoardPlayer callingPlayerScript)
    {
        int playersPoints = callingPlayerScript.addPlayerPoints(20);
        Debug.Log(string.Format("Player 1 Score: {0}\n", playersPoints));
    }
}
