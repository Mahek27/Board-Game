﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowerScript : MonoBehaviour
{

    public Transform targ;
    public GameObject hellaTarg;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, targ.transform.position, (float)0.01);
        /*if (transform.position == targ.position)
        {
            Debug.Log("Hello 456");
            hellaTarg.GetComponent<PlayerController>().helloCall();
        }*/
    }
}