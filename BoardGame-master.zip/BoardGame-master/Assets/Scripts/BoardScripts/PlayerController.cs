﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {
    public Animator animator;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        animator.SetBool("Moving", moveHorizontal != 0 || moveVertical != 0);

        float speedMultiplier = 5;

        transform.Translate(Vector3.up * moveVertical * speedMultiplier * Time.deltaTime);
        transform.Translate(Vector3.right * moveHorizontal * speedMultiplier * Time.deltaTime);
    }

    public void helloCall()
    {
        Debug.Log("Hello World 123!");
    }
}
