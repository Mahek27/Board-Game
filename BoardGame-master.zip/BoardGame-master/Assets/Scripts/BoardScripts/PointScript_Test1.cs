﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PointScript_Test1 : PointScript {

    //public GameObject[] nextPoints;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public override void onLanding(BoardPlayer callingPlayerScript)
    {
        int playersPoints = callingPlayerScript.addPlayerPoints(20);        
        //Debug.Log(string.Format("Player 1 Score: {0}\n", playersPoints));
        callingPlayerScript.setTurnActive(false);
    }
}
