﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BoardPlayer : MonoBehaviour {

    public GameObject currentTarget;
    public GameObject landedTarget;
    public GameObject turnsLeftText;
    public GameObject infoText;
    private Transform targetTransform = null;
    public Animator animator1;
    private int stepsLeft = 0;
    private bool turnActive = false;
    private bool currentlyMoving = false;
    private float xScale;

    public Camera mainCamera;

    public int currentPoints = 0;

    // Audio Clips
    public AudioSource audioSource;
    public AudioClip walkOverSFX;
    public AudioClip landOnSFX;
    public AudioClip bonusSFX;

    private void Awake()
    {
        // Prevent duplicates (might not be necessary)
        if (FindObjectsOfType(GetType()).Length > 1)
        {
            Destroy(gameObject);
        }

        // 
    }

    // Use this for initialization
    void Start () {
        targetTransform = currentTarget.transform;
        turnsLeftText.SetActive(false); // Set this inactive for now
        animator1.SetBool("Moving", false);
        turnsLeftText.GetComponent<Text>().text = string.Format("{0}", stepsLeft);
        xScale = transform.localScale.x;
        //transform.position = targetTransform.position;
    }

    // Update is called once per frame
    void Update()
    {
        mainCamera.transform.position = new Vector3(transform.position.x, transform.position.y, -10);
        if (currentlyMoving && turnActive)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetTransform.transform.position, 3.0f * Time.deltaTime);
            animator1.SetBool("Moving", true);
            var heading = targetTransform.position - transform.position;
            transform.localScale = new Vector2(heading.x >= 0 ? xScale : -xScale, transform.localScale.y);
            //Debug.Log(heading.x);
        }
        if (transform.position == targetTransform.position && currentlyMoving && turnActive)
        {
            stepsLeft--;
            // TODO: HACK: This is a stupid hack to detect one revolution
            if (currentTarget.name == "CirclePoint")
            {
                addPlayerPoints(200, "REVOLUTION BONUS!, YOU RECIEVED 200 POINTS!");
                audioSource.clip = bonusSFX;
                audioSource.Play();
            }
            // Play SFX
            if (stepsLeft > 0)
            {
                audioSource.clip = walkOverSFX;
                audioSource.Play();
            }
            else
            {
                audioSource.clip = landOnSFX;
                audioSource.Play();
            }

            if (stepsLeft <= 0)
            {
                //turnActive = false;
                currentlyMoving = false;
                turnsLeftText.SetActive(false);
                GameObject.Find("StateHolder").GetComponent<StateHolder>().turnsRemaining--;
                // Play sparkle animation
                transform.GetChild(0).gameObject.SetActive(false);
                transform.GetChild(0).gameObject.SetActive(true);
                currentTarget.GetComponent<PointScript>().onLanding(this);
                landedTarget = currentTarget;
            }
            currentTarget = currentTarget.GetComponent<PointScript>().nextPoints[0];
            targetTransform = currentTarget.transform;
            animator1.SetBool("Moving", false);

            turnsLeftText.GetComponent<Text>().text = string.Format("{0}", stepsLeft);
        }
        // DEBUG MINI GAME LOADER
        if (!currentlyMoving)
        {
            if (Input.GetKey(KeyCode.F1))
            {
                landedTarget.GetComponent<PointScript_JSONLoader>().miniGameId = "BrickBreak";
                landedTarget.GetComponent<PointScript>().onLanding(this);
            }
            else if (Input.GetKey(KeyCode.F2))
            {
                landedTarget.GetComponent<PointScript_JSONLoader>().miniGameId = "SpeedDream";
                landedTarget.GetComponent<PointScript>().onLanding(this);
            }
            else if (Input.GetKey(KeyCode.F3))
            {
                landedTarget.GetComponent<PointScript_JSONLoader>().miniGameId = "StrawberrySlasher";
                landedTarget.GetComponent<PointScript>().onLanding(this);
            }
        }
    }

    public void setMovementAmount(int steps)
    {
        stepsLeft = steps;
        turnActive = true;
        currentlyMoving = true;
        turnsLeftText.SetActive(true);
        turnsLeftText.GetComponent<Text>().text = string.Format("{0}", stepsLeft);
    }

    public void setTurnActive(bool turnActive)
    {
        this.turnActive = turnActive;
    }

    public bool getTurnActive()
    {
        return turnActive;
    }

    public int getPlayerPoints()
    {
        return currentPoints;
    }

    public void setPlayerPoints(int points)
    {
        currentPoints = points;
    }

    public int addPlayerPoints(int points)
    {
        currentPoints += points;
        if (points > 0)
        {
            StartCoroutine(DisplayMessage("YOU RECIEVED " + points + " POINTS!", 3));
        }
        return currentPoints;
    }

    public int addPlayerPoints(int points, string customMessage)
    {
        currentPoints += points;
        if (points > 0)
        {
            StartCoroutine(DisplayMessage(customMessage, 3));
        }
        return currentPoints;
    }

    public int subtractPlayerPoints(int points)
    {
        currentPoints -= points;
        return currentPoints;
    }

    private IEnumerator DisplayMessage(string message, int seconds)
    {
        infoText.GetComponent<Text>().text = message;
        infoText.SetActive(true);
        // Enable message
        yield return new WaitForSeconds(seconds);
        infoText.SetActive(false);
    }
}
