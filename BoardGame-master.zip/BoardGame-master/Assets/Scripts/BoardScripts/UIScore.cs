﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIScore : MonoBehaviour {
    public BoardPlayer player1script;

	// Use this for initialization
	void Start () {
        //transform.position = Camera.main.ViewportToWorldPoint(new Vector3(0, 1, 0));
        //player1script = GameObject.Find("Mario-Big").GetComponent<BoardPlayer>();
    }
	
	// Update is called once per frame
	void Update () {
        GetComponent<Text>().text = string.Format("Player 1 (Playing to 300 points in 20 turns)\nScore: {0}\nTurns Remaining: {1}\n", player1script.getPlayerPoints(), GameObject.Find("StateHolder").GetComponent<StateHolder>().turnsRemaining);
    }
}
