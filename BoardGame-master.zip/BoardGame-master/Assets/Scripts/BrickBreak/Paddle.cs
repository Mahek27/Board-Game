﻿using UnityEngine;
using System.Collections;

public class Paddle : MonoBehaviour {

    public float paddleSpeed = 3f;


    private Vector3 playerPos = new Vector3 (0, -10.5f, 0);

    void Update () 
    {
        float xPos = transform.position.x + (Input.GetAxis("Horizontal") * paddleSpeed * Time.deltaTime);
        Debug.Log(xPos - transform.position.x);
        playerPos = new Vector3 (Mathf.Clamp (xPos, -11.5f, 11.5f), -10.5f, 0f);
        transform.position = playerPos;

        if (Input.GetButtonDown("Cancel"))
        {
            Time.timeScale = 1f;
            StateHolder stateHolder = GameObject.Find("StateHolder").GetComponent<StateHolder>();
            stateHolder.returnToBoard(true);
        }
    }
}