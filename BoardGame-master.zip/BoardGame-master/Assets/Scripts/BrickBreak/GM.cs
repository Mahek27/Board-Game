﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GM : MonoBehaviour {

    public int lives = 3;
    public int score;
    public int points;
    public int bricks = 28;
    public float resetDelay = 1f;
    public Text livesText;
    public Text scoreText;
    public GameObject gameOverPanel;
    public GameObject gameOver;
    public GameObject youWon;
    public GameObject bricksPrefab;
    public GameObject paddle;
    public GameObject deathParticles;
    public static GM instance = null;

    private bool winning = false;
	

    private GameObject clonePaddle;

    void Awake () 
    {

        if (instance == null)
            instance = this;
        else if (instance != this)
            Destroy (gameObject);

        Setup();
	scoreText.text = "score: " + score;
    
    }

    public void Setup()
    {
        clonePaddle = Instantiate(paddle, transform.position, Quaternion.identity) as GameObject;
        Instantiate(bricksPrefab, transform.position, Quaternion.identity);
    }

    void CheckGameOver()
    {

        if (bricks < 1)
        {
            youWon.SetActive(true);
            Time.timeScale = .25f;
            //Invoke ("Reset", resetDelay);
            winning = true;
            Invoke("Quit", resetDelay);
        }

        if (lives < 1)
        {
            gameOver.SetActive(true);
            Time.timeScale = .25f;
            //Invoke ("Reset", resetDelay); // this needs to be deleted
	        //gameOverPanel.SetActive (true);
            winning = false;
            Invoke("Quit", resetDelay);
        }
	

    }

    void Reset()
    {
        Time.timeScale = 1f;
        Application.LoadLevel(Application.loadedLevel);
    }
    
    public void LoseLife()
    {
        lives--;
        livesText.text = "Lives: " + lives;
        Instantiate(deathParticles, clonePaddle.transform.position, Quaternion.identity);
        Destroy(clonePaddle);
        Invoke ("SetupPaddle", resetDelay);
        CheckGameOver();
    }





    void SetupPaddle()
    {
        clonePaddle = Instantiate(paddle, transform.position, Quaternion.identity) as GameObject;
    }

    public void DestroyBrick()
    {
	bricks--;
        CheckGameOver();
		
    }
	public void UpdateScore(int points)
	{

		score += points;

		scoreText.text = "score " + score;

	}
	public void PlayAgain()
	{
		SceneManager.LoadScene("Scene Fix");
	}
	public void Quit(){
        //SceneManager.LoadScene("Start Menu");
        // Board reload
        Time.timeScale = 1f;
        StateHolder stateHolder = GameObject.Find("StateHolder").GetComponent<StateHolder>();
        stateHolder.returnToBoard(winning);
    }	
} 