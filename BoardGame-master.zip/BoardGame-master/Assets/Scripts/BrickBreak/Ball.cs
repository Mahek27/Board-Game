﻿using UnityEngine;
using System.Collections;

public class Ball : MonoBehaviour {

    public float ballInitialVelocity = 600f;

public GM GM;

	public int points;

    private Rigidbody rb;
    private bool ballInPlay;
    
    void Awake () {

        rb = GetComponent<Rigidbody>();

	
    
    }
	void OnCollisionEnter (Collision other)
    {

        BrickScript otherScript = other.gameObject.GetComponent<BrickScript>();
        if (otherScript != null)
        {
            GM.instance.UpdateScore(otherScript.points);
        }

    }

    void Update () 
    {
	
        if (Input.GetButtonDown("Fire1") && ballInPlay == false)
        {
            transform.parent = null;
            ballInPlay = true;
            rb.isKinematic = false;
            rb.AddForce(new Vector3(ballInitialVelocity, ballInitialVelocity, 0));

        }

    }

}